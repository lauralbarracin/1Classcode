 // this is the module pattern
 // also called an IIFE
 // an Inmediately Invoked Function Expression 

(()=> {
    // This is a Javascript comment
    console.log('fired! javascript is working');

    // console.log is like print("some text") in python
})();